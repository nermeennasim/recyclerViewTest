package com.example.recyclerviewsample;

public class Article {

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }

    String Title;
    String Content;

    public Article(String title, String content) {
        Title = title;
        Content = content;
    }
}
