package com.example.recyclerviewsample;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomRecycleAdapter extends RecyclerView.Adapter<CustomRecycleAdapter.MyViewHolder> {

    //this arraylist wil be of type Article
    public ArrayList<Article> ArticleList;

    public CustomRecycleAdapter(ArrayList<Article> articleList) {
        this.ArticleList = articleList;
    }

    @NonNull
    @Override
    public CustomRecycleAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        MyViewHolder holder = new MyViewHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomRecycleAdapter.MyViewHolder holder, int position) {
        String title = this.ArticleList.get(position).getTitle();
        String content = this.ArticleList.get(position).getContent();

       //loggin values
        Log.d("MyViewHolder",title);
        Log.d("MyViewHolder",content);
//setting text to views of Custom list item
        holder.txtTitle.setText(title);
        holder.txtContent.setText(content);

    }

    @Override
    public int getItemCount() {

        //size of list
        return ArticleList.size();
    }

    //define view holder custom and assign each text view to its value
    public class MyViewHolder extends
            RecyclerView.ViewHolder {

        private TextView txtTitle;
        private TextView txtContent;

        public MyViewHolder(final View view) {
            super(view);
            txtTitle = view.findViewById(R.id.title);
            txtContent = view.findViewById(R.id.content);
        }


    }
}
