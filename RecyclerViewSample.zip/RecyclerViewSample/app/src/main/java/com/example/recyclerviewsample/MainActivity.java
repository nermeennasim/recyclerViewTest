package com.example.recyclerviewsample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Article> ArticleList;

    RecyclerView myRecyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myRecyclerView =(RecyclerView) findViewById(R.id.mRecyclerView);
        ArticleList = new ArrayList<>();
        ArticleList.add(new Article("Name 1","The PNG format is widely supported and works best with presentations and web design. "));
        ArticleList.add(new Article("Name 2","The PNG format is widely supported and works best with presentations and web design. "));
        ArticleList.add(new Article("Name 3","The PNG format is widely supported and works best with presentations and web design. "));
        ArticleList.add(new Article("Name 4","The PNG format is widely supported and works best with presentations and web design. "));
        ArticleList.add(new Article("Name 5","The PNG format is widely supported and works best with presentations and web design. "));
        ArticleList.add(new Article("Name 6","The PNG format is widely supported and works best with presentations and web design. "));


        System.out.println(ArticleList.get(0).getTitle());
        CustomRecycleAdapter ORecycleAdapter = new CustomRecycleAdapter(ArticleList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        myRecyclerView.setLayoutManager(layoutManager);
      //  myRecyclerView.setItemAnimator(new DefaultItemAnimator());
        myRecyclerView.setAdapter(ORecycleAdapter);

    }

}